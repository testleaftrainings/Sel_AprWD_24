package base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseClass {
	//public static ChromeDriver driver;
	//This is a thread local instance
	private static final ThreadLocal<RemoteWebDriver> remoteWebDriver=new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver() {
		remoteWebDriver.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
		return remoteWebDriver.get();
	}
	
	@BeforeMethod
	public void preCondition() {
	    //driver=new ChromeDriver();
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
		
	}
}
