package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyLeadsPage extends  BaseClass {
	
    @When("Click on create Lead tap")
	public CreateLeadPage clickCreateLeadButton() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage();
	}
	public FindLeadPage clickFindLeadTapButton() {
		getDriver().findElement(By.linkText("Find Leads")).click();
		return new FindLeadPage();
	}
	   @Then("MyLeads Page should be displayed")
		public void verifyMyLeadsPage() {
			String actualTitle="My Leads | opentaps CRM";
			String expectedTitle = getDriver().getTitle();
			if(expectedTitle.equals(actualTitle)) {
				System.out.println("MyLeadsPage verified successfully");
			}else {
				System.out.println("MyLeadsPage not verified successfully");
			}
		}
}
