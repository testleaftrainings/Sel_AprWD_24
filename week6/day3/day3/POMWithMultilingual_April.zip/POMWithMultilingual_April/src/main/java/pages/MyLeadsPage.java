package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class MyLeadsPage  extends BaseClass {

	public CreateLeadPage clickCreateLeadButton() {
		getDriver().findElement(By.linkText(prop.getProperty("MyLeadsPage.clickCreateLeadButton"))).click();
    return new CreateLeadPage();
	}
}
