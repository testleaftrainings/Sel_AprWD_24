package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class FindLeadPage extends BaseClass {
	

	public FindLeadPage clickPhoneTap() {
		getDriver().findElement(By.xpath("//span[text()='Phone']")).click();
		return this;
	}

	public FindLeadPage enterYourPhoneNumber(String mobileNumber) {
		getDriver().findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(mobileNumber);
		return this;
	}

	public FindLeadPage clickFindLeadButton() {
		getDriver().findElement(By.xpath("//button[text()='Find Leads']")).click();
		return this;
	}

	public ViewLeadPage clickFirstResultingLead() throws InterruptedException {
		Thread.sleep(2000);
		getDriver().findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new ViewLeadPage();
	}

	public FindLeadPage enterLeadId() {
		getDriver().findElement(By.xpath("//label[text()='Lead ID:']/following::input")).sendKeys("10062");
		return this;
	}

	public void VerifyDeletedLead() {
		String text = getDriver().findElement(By.xpath("//div[@class='x-toolbar x-small-editor']")).getText();
		System.out.println(text);
	}
}
