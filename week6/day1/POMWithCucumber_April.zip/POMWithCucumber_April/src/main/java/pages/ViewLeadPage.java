
package pages;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewLeadPage  extends BaseClass{
@Then("ViewLeadPage should be displayed")
	public void verifyPageTitle() {
		String expectedTitle = getDriver().getTitle();
		String actualTitle="View Lead | opentaps CRM";
		if(actualTitle.equals(expectedTitle)) {
			System.out.println("Lead created successfully");
		}else {
			System.out.println("Lead not created successfully");
		}
	}
}
