package learnExtentReport;


import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;


public class LearnReport {
public static void main(String[] args) {
	//step1 : set the physical file path
	//ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reporter/result.html");
	
	ExtentSparkReporter reporter=new ExtentSparkReporter("./reporter/result.html");
	//step2 create object extentreporter
	ExtentReports extent =new ExtentReports();
	
	//step3 to attache the report in physical file path
	extent.attachReporter(reporter);
	
	ExtentTest test = extent.createTest("Login","Login with valid credentials");
	test.assignAuthor("Aravind");
	test.assignCategory("Smoke");
	
	
	test.pass("Username Entered successfully");
	test.pass("password Entered successfully");
	test.pass("Login clicked successfully");
	
	ExtentTest test2 = extent.createTest("Login","Login with valid credentials");
	test2.assignAuthor("Vinoth");
	test2.assignCategory("Sanity");
	
	
	test2.pass("Username Entered successfully");
	test2.pass("password Entered successfully");
	test2.pass("Login clicked successfully");
	
	
	
	
	//step4 mandatory method to genetrete html reporter
	extent.flush();
	
}
}
