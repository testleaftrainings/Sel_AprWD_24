package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class HomePage  extends BaseClass{

	public void verifyMessage() {
		String text = getDriver().findElement(By.tagName("h2")).getText();
		System.out.println(text);
	}
	public MyHomePage clickCrmsfaLink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}
}
