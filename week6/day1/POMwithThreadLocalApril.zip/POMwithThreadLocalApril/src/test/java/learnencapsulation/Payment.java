package learnencapsulation;

public class Payment {

	private String creditCardNumber="5555 5555 5555 5555";

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
}
