package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePage  extends BaseClass{
	@Then("HomePage should be displayed")
	public void verifyHomePage() {
		String expectResult = getDriver().getTitle();
		String actualResult="Leaftaps - TestLeaf Automation Platform";
		if(expectResult.equals(actualResult)) {
			System.out.println("The HomePage should be displayed");
		}else {
			System.out.println("The HomePage should not be displayed");
		}

	}
    @When("Click on crmsfa hyper link")
	public MyHomePage clickCrmsfaLink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}
}
