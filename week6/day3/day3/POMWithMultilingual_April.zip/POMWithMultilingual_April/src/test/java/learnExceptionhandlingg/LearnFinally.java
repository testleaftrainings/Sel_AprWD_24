package learnExceptionhandlingg;

import java.util.NoSuchElementException;

public class LearnFinally {
public static void main(String[] args)  {
	
	
	
		try {
			int[] num = { 1, 2, 3, 4, 5 };
			System.out.println(num[5]);
		} finally {
			// TODO: handle finally clause
			System.out.println("Program executed successfully");
		}
	
	
	//System.out.println(c);
	
	
}
}
