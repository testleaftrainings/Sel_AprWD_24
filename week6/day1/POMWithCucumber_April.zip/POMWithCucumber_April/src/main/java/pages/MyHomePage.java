package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyHomePage  extends BaseClass{
	@Then("MyHomePage should be displayed")
	public void verifyMyHomePage() {
		String expectResult = getDriver().getTitle();
		String actualResult="My Home | opentaps CRM";
		if(expectResult.equals(actualResult)) {
			System.out.println("The MyHomePage should be displayed");
		}else {
			System.out.println("The MyHomePage should not be displayed");
		}
	}
	@When("click on leads tap")
	public MyLeadsPage clickLeadsTap() {
		getDriver().findElement(By.linkText("Leads")).click();
		return new MyLeadsPage();
	}
}
