package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class Login extends BaseClass {

	@Test
	public void runLogin() {
		System.out.println(getDriver());
	new LoginPage()
	.enterUserName("Demosalesmanager")
	.enterPassword("crmsfa")
	.clickLoginButton()
	.verifyMessage();
		
		
		
//		LoginPage lp=new LoginPage();
//		lp.enterUserName();
//		lp.enterPassword();
//		lp.clickLoginButton();
//		HomePage hp=new HomePage();
//		hp.verifyMessage();
	}
}
