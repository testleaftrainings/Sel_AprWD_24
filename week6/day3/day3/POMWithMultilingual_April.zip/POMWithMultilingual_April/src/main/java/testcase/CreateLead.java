package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateLead extends BaseClass {

	@Test
	public void runCreateLead() {
		System.out.println(getDriver());
	new LoginPage()
	.enterUserName()
	.enterPassword()
	.clickLoginButton()
	.clickCrmsfaLink()
	.clickLeadsTap()
	.clickCreateLeadButton()
	.enterCompanyName()
	.enterFirstName()
	.enterLastName()
	.clicksubmitButton()
	.verifyPageTitle();
	}
}
