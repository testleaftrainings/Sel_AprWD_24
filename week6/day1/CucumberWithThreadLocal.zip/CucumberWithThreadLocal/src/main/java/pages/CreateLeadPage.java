package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass {
	
    @Given("Enter the comapny name as (.*)$")
	public CreateLeadPage enterCompanyName(String companyName) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
		return this;
	}

    @And("Enter firstName as (.*)$")
	public CreateLeadPage enterFirstName(String firstName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
		return this;
	}

    @And("Enter the lastname as (.*)$")
	public CreateLeadPage enterLastName(String lastName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
		return this;
	}

    @When("click on CreateLead button")
	public ViewLeadPage clickSubmitButton() {
		getDriver().findElement(By.name("submitButton")).click();
		return new ViewLeadPage();
	}
    @Then("CreateLeadPage should be displayed")
	public void verifyCreateLeadPage() {
		String actualTitle="My Leads | opentaps CRM";
		String expectedTitle = getDriver().getTitle();
		if(expectedTitle.equals(actualTitle)) {
			System.out.println("CreateLeadPage verified successfully");
		}else {
			System.out.println("CreateLeadpage not verified successfully");
		}
	}
}
