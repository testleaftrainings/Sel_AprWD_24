package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class CreateLeadPage  extends BaseClass{

	public CreateLeadPage enterCompanyName() {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(prop.getProperty("CreateLeadPage.enterCompanyName"));
		return this;
}
	public CreateLeadPage enterFirstName() {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(prop.getProperty("CreateLeadPage.enterFirstName"));
		return this;
	}
	public CreateLeadPage enterLastName() {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(prop.getProperty("CreateLeadPage.enterLastName"));
		return this;
	}
	public ViewLeadPage clicksubmitButton() {
		getDriver().findElement(By.name("submitButton")).click();
		return new ViewLeadPage();
	}
}
