package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseClass {
	//public static ChromeDriver driver;
	//This is a thread local instance
	private static final ThreadLocal<RemoteWebDriver> remoteWebDriver=new ThreadLocal<RemoteWebDriver>();
	public static Properties prop;
	public void setDriver() {
		remoteWebDriver.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
		return remoteWebDriver.get();
	}
	
	@BeforeMethod
	public void preCondition() throws IOException {
	    //driver=new ChromeDriver();
		FileInputStream fis =new FileInputStream("src/main/resources/Leaftaps.properties");
	    prop=new Properties();
		prop.load(fis);
		setDriver();
		getDriver().get(prop.getProperty("url"));
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
		
	}
}
