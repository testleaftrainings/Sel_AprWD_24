package learnencapsulation;

public class MyPayments {
public static void main(String[] args) {
	
	Payment pay=new Payment();
	pay.setCreditCardNumber("1111 1111 1111 1111");
	System.out.println(pay.getCreditCardNumber());
}
}
