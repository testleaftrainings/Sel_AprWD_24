package learnExceptionhandlingg;

import java.util.NoSuchElementException;

public class LearnException {
public static void main(String[] args) throws NoSuchElementException {
	int a=10;
	
	int c = 0;
	
	try {
	//	c = a/0;
		int[] num= {1,2,3,4,5};
		System.out.println(num[5]);
	} catch (ArithmeticException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
	catch (ArrayIndexOutOfBoundsException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
	catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
	System.out.println(c);
	
	System.out.println("Program executed successfully");
}
}
