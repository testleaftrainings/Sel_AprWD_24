
package pages;

import base.BaseClass;

public class ViewLeadPage  extends BaseClass{

	public void verifyPageTitle() {
		String expectedTitle = driver.getTitle();
		String actualTitle="View Lead | opentaps CRM";
		if(actualTitle.equals(expectedTitle)) {
			System.out.println("Lead created successfully");
		}else {
			System.out.println("Lead not created successfully");
		}
	}
}
