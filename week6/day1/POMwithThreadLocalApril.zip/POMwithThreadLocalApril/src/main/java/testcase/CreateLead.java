package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateLead extends BaseClass {

	@Test
	public void runCreateLead() {
		System.out.println(getDriver());
	new LoginPage()
	.enterUserName("Demosalesmanager")
	.enterPassword("crmsfa")
	.clickLoginButton()
	.clickCrmsfaLink()
	.clickLeadsTap()
	.clickCreateLeadButton()
	.enterCompanyName("Infosys")
	.enterFirstName("Aravind")
	.enterLastName("RK")
	.clicksubmitButton()
	.verifyPageTitle();
	}
}
