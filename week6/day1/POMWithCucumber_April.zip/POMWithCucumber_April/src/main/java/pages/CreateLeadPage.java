package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLeadPage  extends BaseClass{
	@Then("CreateLead pages should be displayed")
	public void verifyCreateLeadPage() {
		String expectResult = getDriver().getTitle();
		String actualResult="Create Lead | opentaps CRM";
		if(expectResult.equals(actualResult)) {
			System.out.println("The CreateLeadpage should be displayed");
		}else {
			System.out.println("The CreateLeadpage should not be displayed");
		}
	}
	@Given("Enter the companyName as (.*)$")
	public CreateLeadPage enterCompanyName(String companyName) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
		return this;
	}
	@And("Enter the FirstName as (.*)$")
	public CreateLeadPage enterFirstName(String firstName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
		return this;
	}
	@And("Enter the LastName as (.*)$")
	public CreateLeadPage enterLastName(String lastName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
		return this;
	}
	@When("Click on CreateLead submit button")
	public ViewLeadPage clicksubmitButton() {
		getDriver().findElement(By.name("submitButton")).click();
		return new ViewLeadPage();
	}
}
