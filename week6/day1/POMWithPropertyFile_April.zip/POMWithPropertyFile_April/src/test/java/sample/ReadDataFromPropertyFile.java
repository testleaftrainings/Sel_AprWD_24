package sample;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadDataFromPropertyFile {
public static void main(String[] args) throws IOException {
	//to set the path
	FileInputStream fis =new FileInputStream("src/main/resources/Leaftaps.properties");
	
	//Create a object for properties class
	Properties prop=new Properties();
	
	//to load the data from property file
	prop.load(fis);
	
	String url = prop.getProperty("url");
	System.out.println(url);
	
	String username = prop.getProperty("userName");
	System.out.println(username);
	
	String password = prop.getProperty("password");
	System.out.println(password);
}
}
