package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyLeadsPage  extends BaseClass {
	@Then("MyLeadsPage should be displayed")
	public void verifyMyLeadsPage() {
		String expectResult = getDriver().getTitle();
		String actualResult="My Leads | opentaps CRM";
		if(expectResult.equals(actualResult)) {
			System.out.println("The MyLeadsPage should be displayed");
		}else {
			System.out.println("The MyLeadsPage should not be displayed");
		}
	}
	@When("Click on create Lead button")
	public CreateLeadPage clickCreateLeadButton() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage();
	}
}
