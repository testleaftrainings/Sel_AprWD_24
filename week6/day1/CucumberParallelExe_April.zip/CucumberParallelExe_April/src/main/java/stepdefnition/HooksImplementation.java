package stepdefnition;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class HooksImplementation  extends BaseClass{
	
	@Before
	public void preCondition() {
	//	driver=new ChromeDriver();
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}


	@After
	public void postCondition() {
		getDriver().quit();
	}

}
